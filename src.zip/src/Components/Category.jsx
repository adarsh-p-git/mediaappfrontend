import React, { useState } from 'react'
import { Button, Modal,Form } from 'react-bootstrap'



function Category() {

  const [show, setShow] = useState(false)

  const handleClose = () => setShow(false)
  const handleShow = () => setShow(true)

  return (
   <>

   <div className='d-grid ms-3'>
   <button type="button" class="btn btn-primary btn-sm" onClick={handleShow}>
            Add to Category
   </button>
   </div>

   {/* modal */}

   <Modal show={show} onHide={handleClose} backdrop="static" keyboard={false}>
        <Modal.Header closeButton>
          <Modal.Title>Modal title</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>FILL THE FOLLOWING FIELDS</p>
          <Form>
            <Form.Control type="text" placeholder="Enter Video Id" />
            <br />
            <Form.Control type="text" placeholder="Enter Video Title" />
            <br />
         
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            CANCEL
          </Button>
          <Button variant="primary">UPLOAD</Button>
        </Modal.Footer>
      </Modal>

   </>
  )
}

export default Category
