import React from 'react'
import { Link } from 'react-router-dom'


function WatchHistory() {
  return (
    <>

    <div className="container mt-5 mb-5 d-flex justify-content-between">
      <h3>Watch History</h3>
      <Link to={'/home'} style={{textDecoration:'none',fontSize:'20px',color:'white'}}>
      <i class="fa-solid fa-arrow-left-long fa-beat-fade"></i> Back to Home
      </Link>
    </div>

    <table className='table mt-5 mb-5 container'>
      <thead>
        <th>#</th>
        <th>Name</th>
        <th>URL</th>
        <th>TimeStamp</th>
        </thead>

        <tbody>
          <td>1</td>
          <td>Video</td>
          <td>Image</td>
          <td>Video</td>
        </tbody>
    </table>

    {/* new */}

    <table class="table table-hover" className='mt-5 mb-5 container'>
    <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">URL</th>
      <th scope="col">Timestamp</th>
    </tr>
  </thead>

  <tr class="table-secondary">
      <th scope="row">1</th>
      <td>video</td>
      <td>image</td>
      <td>video</td>
    </tr>
    
    </table>

    
    </>
  )
}

export default WatchHistory
